/**
 *@file connect.h
 *@brief Soubor constant potrebnych pro pripojeni k databazi nebo k Jabber uctu robota.
 */

#ifndef CONNECT_H__
#define CONNECT_H__


//#define DEF_LOGIN "JabInfo@jabbim.com/bot"
//#define DEF_PASS "xse20IPB10"

#define DEF_LOGIN "konsole@localhost/bot"
#define DEF_PASS "javier"



#define DB_SERV "localhost"
#define DB_ADDR "127.0.0.1"
#define DB_PORT "" 
#define DB_USER "portilo"
#define DB_PASS "trewq"
#define DB_NAME "portilo"
#define DB_TIME "10"


/*
#define DB_SERV "localhost"
#define DB_ADDR "147.229.12.139"
#define DB_PORT "" 
#define DB_USER "xsendl00"
#define DB_PASS "e5bd224e6d"
#define DB_NAME "xsendl00"
#define DB_TIME "10"
*/

#define AVAILABLE 120
#define AWAY 90
#define DND 50
#define CHAT 110
#define XA 70
#define UNAVALIABLE 0


#define DATE_START "2011-05-07 12:02:20"
#define DATE_END "2011-05-07 13:34:05"


#endif // CONNECT_H__
